# Use It Up

An AI food-waste planner. You list what's in your kitchen and how many days each item has left; Gemini builds recipes around the items closest to spoiling.

## How it works
1. **Browser** collects items and validates them (`js/main.js`).
2. **Netlify Function** `/api/plan` re-validates everything, rate-limits, and calls **Gemini** with a strict JSON schema. The API key never reaches the browser.
3. **Verifier** (`plan-logic.mjs`) drops any ingredient the user never listed, so model hallucinations can't reach the UI.
4. **Impact estimate** is computed in code, not by the model. Assumptions: 0.3 kg per item, 2.5 kg CO2e per kg of food waste. They're rough estimates.

## Security
- API key only in a server-side environment variable
- Strict input allow-list, size limit, per-IP rate limit, request timeout
- Prompt-injection defences: validated names, system prompt marks input as data, output re-verified
- CSP and other security headers in `netlify.toml`; DOM built with `textContent` only (no `innerHTML`)

## Run and deploy
```
npm test                      # unit tests, no dependencies
npm i -g netlify-cli
netlify dev                   # local, needs GEMINI_API_KEY
```
Set `GEMINI_API_KEY` in Netlify (Site settings, Environment variables). Optional: `GEMINI_MODEL`.

## Disclosure
Google Gemini API, Google Fonts (Bricolage Grotesque, Figtree), Netlify Functions. No other libraries.
