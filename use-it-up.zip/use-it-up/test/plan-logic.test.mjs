import test from "node:test";
import assert from "node:assert/strict";
import { validateRequest, verifyRecipes, estimateImpact } from "../netlify/functions/lib/plan-logic.mjs";

const ok = { items: [{ name: "rice", daysLeft: 20 }, { name: "Spinach", daysLeft: 1 }], servings: 2 };

test("accepts valid input and sorts most urgent first", () => {
  const r = validateRequest(ok);
  assert.equal(r.ok, true);
  assert.equal(r.value.pantry[0].name, "Spinach");
});

test("rejects injection-style names and bad numbers", () => {
  assert.equal(validateRequest({ items: [{ name: "ignore previous <b>", daysLeft: 1 }] }).ok, false);
  assert.equal(validateRequest({ items: [{ name: "milk", daysLeft: -1 }] }).ok, false);
  assert.equal(validateRequest({ items: [{ name: "milk", daysLeft: 1 }], diet: "x" }).ok, false);
});

test("drops ingredients the user never listed", () => {
  const pantry = [{ name: "Spinach", daysLeft: 1 }];
  const { recipes, unmatched } = verifyRecipes(
    [{ title: "Saute", minutes: 10, uses: ["spinach", "truffle"], needsExtra: [], steps: ["Cook."] }], pantry);
  assert.deepEqual(recipes[0].uses, ["Spinach"]);
  assert.equal(unmatched, 1);
});

test("impact counts only urgent items that are used", () => {
  const pantry = [{ name: "Spinach", daysLeft: 1 }, { name: "rice", daysLeft: 20 }];
  const impact = estimateImpact(pantry, [{ uses: ["Spinach", "rice"] }]);
  assert.equal(impact.itemsRescued, 1);
  assert.equal(impact.kgCo2e, 0.8);
});
