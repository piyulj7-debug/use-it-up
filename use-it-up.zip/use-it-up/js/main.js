import { requestPlan } from "./api.js";

const NAME_RE = /^[\p{L}\p{N}][\p{L}\p{N} '\-]{0,39}$/u;
const MAX_ITEMS = 30;
const EXAMPLE = [
  { name: "Spinach", daysLeft: 1 }, { name: "Greek yogurt", daysLeft: 2 }, { name: "Bananas", daysLeft: 2 },
  { name: "Chickpeas", daysLeft: 25 }, { name: "Tomatoes", daysLeft: 4 }, { name: "Rice", daysLeft: 30 },
];

const $ = (sel) => document.querySelector(sel);
const ui = {
  form: $("#add-form"), name: $("#item-name"), days: $("#item-days"), formError: $("#form-error"),
  list: $("#item-list"), empty: $("#empty-note"), plan: $("#make-plan"), output: $("#plan-output"),
  region: $(".plan"), diet: $("#diet"), servings: $("#servings"),
};

let items = [];

/** Build DOM safely: text only, never innerHTML. */
function el(tag, { text, className, attrs } = {}, ...children) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  if (className) node.className = className;
  Object.entries(attrs ?? {}).forEach(([k, v]) => node.setAttribute(k, v));
  node.append(...children);
  return node;
}

const urgencyOf = (days) => (days <= 2 ? "urgent" : days <= 5 ? "soon" : "fresh");
const daysLabel = (d) => (d === 0 ? "Use today" : `${d} day${d === 1 ? "" : "s"} left`);

function renderItems() {
  const sorted = [...items].sort((a, b) => a.daysLeft - b.daysLeft);
  ui.list.replaceChildren(...sorted.map((item) => {
    const row = el("li", { className: "item", attrs: { "data-urgency": urgencyOf(item.daysLeft) } },
      el("span", { className: "item-name", text: item.name }),
      el("span", { className: "item-days", text: daysLabel(item.daysLeft) }),
      el("button", { className: "remove", text: "Remove", attrs: { type: "button", "aria-label": `Remove ${item.name}`, "data-name": item.name } }),
      el("div", { className: "meter", attrs: { "aria-hidden": "true" } }, el("span")));
    row.querySelector(".meter > span").style.setProperty("--fill", `${Math.max(6, (Math.min(item.daysLeft, 14) / 14) * 100)}%`);
    return row;
  }));
  ui.empty.hidden = items.length > 0;
  ui.plan.disabled = items.length === 0;
}

function showFormError(message) {
  ui.formError.textContent = message;
  ui.formError.hidden = !message;
}

function addItem(event) {
  event.preventDefault();
  const name = ui.name.value.trim();
  const daysLeft = Number(ui.days.value);
  if (!NAME_RE.test(name)) return showFormError("Use letters, numbers, spaces, hyphens or apostrophes (40 characters max).");
  if (!Number.isInteger(daysLeft) || daysLeft < 0 || daysLeft > 30) return showFormError("Days left must be a whole number from 0 to 30.");
  if (items.length >= MAX_ITEMS) return showFormError(`You can add up to ${MAX_ITEMS} items.`);
  if (items.some((i) => i.name.toLowerCase() === name.toLowerCase())) return showFormError(`${name} is already on the list.`);
  showFormError("");
  items.push({ name, daysLeft });
  ui.name.value = "";
  ui.name.focus();
  renderItems();
}

function renderPlan(data) {
  const { impact, recipes, tip, unmatched } = data;
  const nodes = [
    el("p", { className: "impact", text: `Saves ${impact.itemsRescued} of ${impact.urgentTotal} urgent items, about ${impact.kgCo2e} kg CO₂e (estimate).` }),
    ...recipes.map((r) => el("article", { className: "recipe" },
      el("h3", { text: r.title }),
      el("p", { className: "meta", text: `${r.minutes} minutes` }),
      el("ul", { className: "chips", attrs: { "aria-label": "Uses from your kitchen" } }, ...r.uses.map((u) => el("li", { className: "chip", text: u }))),
      el("ol", {}, ...r.steps.map((s) => el("li", { text: s }))),
      r.needsExtra.length ? el("p", { className: "note", text: `Also needed: ${r.needsExtra.join(", ")}` }) : el("span"))),
  ];
  if (tip) nodes.push(el("p", { className: "note", text: tip }));
  if (unmatched) nodes.push(el("p", { className: "note", text: "Some suggested ingredients weren't on your list and were removed." }));
  ui.output.replaceChildren(...nodes);
}

async function makePlan() {
  ui.plan.disabled = true;
  ui.region.setAttribute("aria-busy", "true");
  ui.output.replaceChildren(el("div", { className: "spinner", attrs: { role: "status", "aria-label": "Planning" } }));
  try {
    renderPlan(await requestPlan({ items, diet: ui.diet.value, servings: Number(ui.servings.value) }));
  } catch (err) {
    ui.output.replaceChildren(el("p", { className: "error", text: err.message, attrs: { role: "alert" } }));
  } finally {
    ui.region.setAttribute("aria-busy", "false");
    ui.plan.disabled = items.length === 0;
  }
}

ui.form.addEventListener("submit", addItem);
ui.plan.addEventListener("click", makePlan);
$("#load-example").addEventListener("click", () => { items = EXAMPLE.map((i) => ({ ...i })); renderItems(); });
ui.list.addEventListener("click", (e) => {
  const name = e.target.closest(".remove")?.dataset.name;
  if (name) { items = items.filter((i) => i.name !== name); renderItems(); }
});
renderItems();
